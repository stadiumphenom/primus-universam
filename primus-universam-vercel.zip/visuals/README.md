# Visuals

This folder will hold galaxy maps, recursion diagrams, and orbit visualizations for Primus-Universum.
