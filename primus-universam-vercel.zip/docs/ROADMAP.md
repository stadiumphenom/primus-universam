# Roadmap

- ✅ Phase 1: Core engine + Streamlit MVP
- 🔄 Phase 2: Visualizations, tests, and memory persistence
- 🚀 Phase 3: Expand to multi-orbit recursion, energy balancing, alien logic
