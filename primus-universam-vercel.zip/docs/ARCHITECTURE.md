# Architecture Notes

- **Engine**: Core recursive pulse logic.
- **Data**: Seed maps and configurations.
- **App**: Streamlit dashboard.
- **Docs**: Philosophy, architecture, roadmap.
